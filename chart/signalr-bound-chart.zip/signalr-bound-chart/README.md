#Binding to SignalR hub

This example demonstrates real-time push-notifications from SignalR(v2) with local hub. To see the real-time updates:

1. Start the project and open the home page.
1. Create, update or destroy items in the Grid below the Chart.

The Grid is loaded in an IFRAME to simulate a remote client.

